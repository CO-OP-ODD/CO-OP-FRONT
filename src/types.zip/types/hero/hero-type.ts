export type TypeNewsItem = {
    title: string;
    description: string;
    img: string;
}
