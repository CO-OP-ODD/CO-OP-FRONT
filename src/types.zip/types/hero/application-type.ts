export type TypeApplication = {
    img?: string;
    title: string;
    description?: string;
    href?: string;
}
