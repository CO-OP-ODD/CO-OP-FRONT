export type TypeProduct = {
    imgUrl: string;
    tags?: string[];
    name: string;
    price?: number;
}
